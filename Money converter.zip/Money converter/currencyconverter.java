import java.util.Scanner;

public class CurrencyConverter {
    private double amount;

    public void setAmount(double amt) {
        this.amount = amt;
    }

    public double convert(String from, String to) {
        double rate = getRate(from, to);
        return amount * rate;
    }

    private double getRate(String from, String to) {
        if (from.equals("INR") && to.equals("USD")) return 0.012;
        else if (from.equals("USD") && to.equals("INR")) return 83.2;
        else if (from.equals("EUR") && to.equals("INR")) return 89.5;
        // Add more as needed
        else return 1.0;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CurrencyConverter cc = new CurrencyConverter();
        
        System.out.print("Enter amount: ");
        double amt = sc.nextDouble();
        sc.nextLine();
        
        System.out.print("From currency (INR/USD/EUR): ");
        String from = sc.nextLine();
        
        System.out.print("To currency (INR/USD/EUR): ");
        String to = sc.nextLine();
        
        cc.setAmount(amt);
        double result = cc.convert(from.toUpperCase(), to.toUpperCase());
        System.out.println("Converted Amount: " + result);
    }
}
